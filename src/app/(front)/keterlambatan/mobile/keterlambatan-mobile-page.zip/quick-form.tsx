"use client"

import { useEffect, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import api from "@/lib/axios"
import { Siswa, Keterlambatan } from "../types"

export function QuickForm({ onSuccess }: { onSuccess: (data: Keterlambatan) => void }) {
  const [form, setForm] = useState<Partial<Keterlambatan>>({})
  const [siswaList, setSiswaList] = useState<Siswa[]>([])
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<{ [key: string]: string[] }>({})

  useEffect(() => {
    api.get("/siswas").then(res => setSiswaList(res.data.data))
    const now = new Date()
    setForm({
      tanggal: now.toISOString().slice(0, 10),
      waktu_datang: now.toTimeString().slice(0, 5),
    })
  }, [])

  const handleSubmit = async (e: any) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await api.post("/keterlambatans", form)
      setErrors({})
      setForm({ tanggal: form.tanggal, waktu_datang: form.waktu_datang })
      onSuccess(res.data.data)
    } catch (err: any) {
      if (err.response?.status === 422) {
        setErrors(err.response.data.errors)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <select
        className="w-full border px-3 py-2 rounded"
        value={form.siswa_id || ""}
        onChange={(e) => setForm({ ...form, siswa_id: Number(e.target.value) })}
        required
      >
        <option value="">-- Pilih Nama Siswa --</option>
        {siswaList.map((siswa) => (
          <option key={siswa.id} value={siswa.id}>{siswa.nama}</option>
        ))}
      </select>
      {errors?.siswa_id && <p className="text-sm text-red-600">{errors.siswa_id[0]}</p>}

      <Input
        type="time"
        value={form.waktu_datang || ""}
        onChange={(e) => setForm({ ...form, waktu_datang: e.target.value })}
        required
      />

      <Input
        placeholder="Keterangan (opsional)"
        value={form.keterangan || ""}
        onChange={(e) => setForm({ ...form, keterangan: e.target.value })}
      />

      <Button type="submit" disabled={loading} className="w-full">
        {loading ? "Menyimpan..." : "Simpan"}
      </Button>
    </form>
  )
}
