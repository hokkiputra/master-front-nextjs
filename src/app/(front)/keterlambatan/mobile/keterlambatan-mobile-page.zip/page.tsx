"use client"

import { useEffect, useState } from "react"
import { QuickForm } from "./quick-form"
import { Keterlambatan } from "../types"
import { Card } from "@/components/ui/card"

export default function MobileKeterlambatanPage() {
  const [recent, setRecent] = useState<Keterlambatan[]>([])

  const handleSuccess = (data: Keterlambatan) => {
    setRecent([data, ...recent].slice(0, 5)) // simpan 5 terakhir
  }

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold text-center">Catat Keterlambatan</h1>
      <QuickForm onSuccess={handleSuccess} />
      <div>
        <h2 className="font-semibold mb-2">Terakhir Dicatat:</h2>
        {recent.length === 0 && <p className="text-muted-foreground">Belum ada data.</p>}
        {recent.map((item, i) => (
          <Card key={i} className="p-3 mb-2">
            <div className="font-semibold">{item.siswa?.nama}</div>
            <div className="text-sm text-muted-foreground">
              {item.tanggal} jam {item.waktu_datang}
            </div>
            {item.keterangan && <div className="text-sm">{item.keterangan}</div>}
          </Card>
        ))}
      </div>
    </div>
  )
}
