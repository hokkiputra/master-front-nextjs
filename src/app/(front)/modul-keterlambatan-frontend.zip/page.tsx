"use client"

import { useEffect, useState } from "react"
import { columns as getColumns } from "./columns"
import { Keterlambatan } from "./types"
import { DataTable } from "@/components/layouts/data-table"
import { FormDialog } from "./form-dialog"
import api from "@/lib/axios"
import Cookies from "js-cookie"
import { Button } from "@/components/ui/button"

export default function KeterlambatanPage() {
  const [data, setData] = useState<Keterlambatan[]>([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(false)
  const [editData, setEditData] = useState<Keterlambatan | null>(null)

  const token = Cookies.get("token")

  const fetchData = () => {
    api.get("/api/keterlambatan", {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => setData(res.data.data))
      .finally(() => setLoading(false))
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = (form: Partial<Keterlambatan>, id?: number) => {
    const request = id
      ? api.put(`/api/keterlambatan/${id}`, form, { headers: { Authorization: `Bearer ${token}` } })
      : api.post(`/api/keterlambatan`, form, { headers: { Authorization: `Bearer ${token}` } })

    request.then(() => {
      fetchData()
      setOpen(false)
    })
  }

  const handleDelete = (id: number) => {
    if (!confirm("Yakin hapus data ini?")) return
    api.delete(`/api/keterlambatan/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then(fetchData)
  }

  if (loading) return <p className="p-4">Loading...</p>

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Keterlambatan Siswa</h1>
        <Button onClick={() => { setEditData(null); setOpen(true) }}>+ Tambah</Button>
      </div>
      <DataTable columns={getColumns({ onEdit: setEditData, onDelete: handleDelete })} data={data} filterKey="siswa.nama" />
      <FormDialog open={open} onClose={() => setOpen(false)} onSubmit={handleSubmit} initialData={editData} />
    </div>
  )
}
