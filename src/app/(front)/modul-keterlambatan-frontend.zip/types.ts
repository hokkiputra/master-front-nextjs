export interface Keterlambatan {
  id: number
  siswa_id: number
  tanggal: string
  waktu_datang: string
  status: string
  keterangan?: string
  siswa?: {
    nama: string
  }
}

export interface Siswa {
  id: number
  nama: string
}
